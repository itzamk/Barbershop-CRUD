CREATE TABLE FP_Customers (  
    customerID INT PRIMARY KEY,
    customerFirstName VARCHAR(30) NOT NULL,
    customerLastName VARCHAR(30) NOT NULL,
    customerPhoneNumber VARCHAR(20) NOT NULL
);