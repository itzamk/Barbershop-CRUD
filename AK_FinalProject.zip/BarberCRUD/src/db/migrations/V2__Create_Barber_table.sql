CREATE TABLE FP_Barber (  
    barberID INT PRIMARY KEY,
    barberFirstName VARCHAR(30) NOT NULL,
    barberLastName VARCHAR(30) NOT NULL,
    barberSSN VARCHAR(20) NOT NULL
);